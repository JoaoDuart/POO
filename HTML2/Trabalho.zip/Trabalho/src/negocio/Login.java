package negocio;

import dados.Usuario;

import java.util.HashMap;
import java.util.Map;

public class Login {
    private Map<String, Usuario> usuarios;

    public Login() {
        this.usuarios = new HashMap<>();
    }

    public void adicionaUsuario(String nome, Usuario usuario) {
        usuarios.put(nome, usuario);
    }

    public void alteraUsuario(String nome, Usuario novoUsuario) {
        if (usuarios.containsKey(nome)) {
            usuarios.put(nome, novoUsuario);
        } else {
            System.out.println("Usuário não encontrado.");
        }
    }

    public void removeUsuario(String nome) {
        usuarios.remove(nome);
    }

    public Usuario getUsuario(String nome) {
        return usuarios.get(nome);
    }

    public boolean verificarCredenciais(String nome, String senha) {
        if (usuarios.containsKey(nome)) {
            Usuario usuario = usuarios.get(nome);
            return usuario.getSenha().equals(senha);
        } else {
            System.out.println("Usuário não encontrado.");
            return false;
        }
    }
}