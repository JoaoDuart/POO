package negocio;

import dados.Gasto;
import dados.Receita;

import java.util.ArrayList;
import java.util.List;

public class Sistema {
    private List<Gasto> gastos;
    private List<Receita> receitas;

    public Sistema() {
        this.gastos = new ArrayList<>();
        this.receitas = new ArrayList<>();
    }

    public void adicionaGasto(Gasto gasto) {
        gastos.add(gasto);
    }

    public void removeGasto(Gasto gasto) {
        gastos.remove(gasto);
    }

    public void adicionaReceita(Receita receita) {
        receitas.add(receita);
    }

    public void removeReceita(Receita receita) {
        receitas.remove(receita);
    }

    public void listaEntradasEGastos() {
        System.out.println("Lista de Gastos:");
        for (Gasto gasto : gastos) {
            System.out.println("Nome: " + gasto.getNome() + ", Descrição: " + gasto.getDescricao() + ", Valor: "
                    + gasto.getValor());
        }

        System.out.println("\nLista de Receitas:");
        for (Receita receita : receitas) {
            System.out.println("Nome: " + receita.getNome() + ", Descrição: " + receita.getDescricao() + ", Valor: "
                    + receita.getValor());
        }
    }

    public double calculaTotal() {
        double total = 0.0;

        for (Gasto gasto : gastos) {
            total -= gasto.getValor();
        }

        for (Receita receita : receitas) {
            total += receita.getValor();
        }

        return total;
    }
}
